# CCM Tool v0.60.7

**Cross-Country Mobility Analysis Tool**

A comprehensive Python-based desktop toolbox for analyzing terrain mobility and generating least-cost path routes across digital elevation models, incorporating multi-factor terrain assessment with vehicle-specific mobility curves.

---

## Quick Start

### Installation

1. Ensure ArcGIS Pro is installed with Python environment configured
2. Clone or download the CCM_Tool_v0.60.7 repository
3. Install dependencies:
   ```bash
   pip install numpy gdal pandas scipy arcpy
   ```
4. Import the toolbox into ArcGIS Pro
5. Configure input DEM and vehicle parameters
6. Run the mobility analysis and pathfinding workflows

### Basic Usage

```python
# Example: Analyze terrain mobility for specific vehicle
from CCM_Tool import MobilityAnalysis

# Initialize with DEM and vehicle specifications
analyzer = MobilityAnalysis(dem_raster='path/to/dem.tif',
                             vehicle='M1_Abrams',
                             slope_factor=0.8)

# Generate mobility surface
mobility_surface = analyzer.calculate_terrain_mobility()

# Find least-cost path
optimal_path = analyzer.find_least_cost_path(start, end, mobility_surface)
```

---

## Features

### Core Capabilities

- **Multi-Factor Terrain Mobility Assessment**: Integrates slope, soil classification, vegetation type, hydrology, and weather conditions
- **Vehicle-Specific Mobility Curves**: Pre-configured curves for military and civilian vehicles based on NATO Reference Mobility Model (NRMM)
- **Least-Cost Path Algorithm**: Dijkstra-based pathfinding with 8-directional connectivity
- **Raster Algebra Processing**: Efficient map algebra operations for large-scale DEM analysis
- **ArcGIS Pro Integration**: Native Python toolbox for seamless GIS workflow integration
- **Customizable Parameters**: User-defined terrain weights, vehicle specifications, and environmental factors
- **Automated Report Generation**: Produces mobility maps, path analysis, and movement statistics

---

## Data Sources & Attribution

### Public Domain Standards & Data

This tool utilizes several public domain and open-source standards. For complete attribution details, please refer to the following documentation files:

#### **ATTRIBUTION.md** — Third-Party Credits & Licenses
Comprehensive documentation of all external data sources and library licenses, including:
- **NATO Reference Mobility Model (NRMM)** — Public domain standard
- **USCS Soil Classification (ASTM D5080)** — Public standard for terrain analysis
- **External Libraries**: NumPy (BSD), GDAL (MIT), Pandas (BSD), SciPy (BSD)
- Citation examples for academic and professional publications

#### **DATA_SOURCES.md** — Complete Reference Guide (12,000+ words)
Detailed technical documentation covering:
- **NRMM Vehicle Data** (`Vehicle_Data/Vehicles_Can.csv`) — Public domain NATO standard
- **USCS CNI Values** (`soil_rci.csv`) — Public ASTM D5080 standard
- **DEM Processing**: Best practices and data format requirements
- **Vegetation, Soil & Hydrology Data**: User-provided data attribution guidance
- **Algorithm Standards**: Dijkstra (1959), slope/aspect calculations, raster algebra (Tomlin 1990)
- **External Libraries**: Complete licensing breakdown
- **Citation Templates**: For different publication and use contexts
- **Compliance Guidance**: For government, academic, and commercial applications

#### **ALGORITHM.md** — Technical Implementation Details
Verification of independent implementation:
- **Dijkstra Algorithm Foundation** (1959) — Industry standard for shortest-path problems
- **8-Directional Raster Connectivity**: Efficient grid-based pathfinding
- **Mobility Surface Generation**: Multi-factor terrain cost accumulation
- **Technical Comparison with Enhanced_CostPath_withParameters**: Confirms different design focus (LCP smoothing vs. multi-factor mobility assessment)
- **Technical Comparison with ESRI Version**: Confirms different architecture (web app vs. desktop toolbox)
- **Performance Characteristics**: O(n log n) complexity, raster-based efficiency
- **Verification Status**: ✅ Independent implementation confirmed

### Quick Attribution Statement

If you publish results using this tool, please include the following attribution:

```
This analysis was conducted using the CCM Tool v0.60.7, which incorporates:
- NATO Reference Mobility Model (NRMM) for vehicle mobility parameters
- USCS Soil Classification System (ASTM D5080) for terrain assessment
- Dijkstra's algorithm (1959) for optimal path computation
- Raster algebra operations following Tomlin (1990) cartographic modeling principles
```

---

## Algorithm Documentation

### Core Algorithm: Least-Cost Path (LCP)

The CCM Tool implements a Dijkstra-based least-cost path algorithm that operates on raster-based terrain data:

1. **Mobility Surface Generation**: Multi-factor terrain assessment produces a cost surface combining:
   - Slope analysis and aspect calculations
   - Soil trafficability indices (NRMM-based)
   - Vegetation impedance factors
   - Hydrological constraints
   - Weather and seasonal conditions

2. **8-Directional Grid Pathfinding**: Efficient priority-queue based search:
   - Cost accumulation following 8-directional connectivity rules
   - Simultaneous horizontal and diagonal movement evaluation
   - Optimal path reconstruction from cost surface

3. **Vehicle-Specific Mobility Curves**: Pre-configured mobility performance data:
   - NATO Reference Mobility Model (NRMM) specifications
   - Terrain type interaction matrices
   - Speed reduction factors across different slope/soil combinations

### Key Design Differentiators

**vs. Enhanced_CostPath_withParameters (2025)**:
- Enhanced focuses on pure LCP optimization with smoothing post-processing (~500 lines)
- CCM Tool emphasizes multi-factor terrain mobility assessment across 54 integrated modules
- Different specialization: smoothing algorithms vs. vehicle-terrain interactions

**vs. ESRI Version (2017)**:
- ESRI: JavaScript-based web application, REST API calls to remote service
- CCM Tool: Python desktop toolbox, local computation for full data control
- Different deployment model: web service vs. offline GIS integration

For complete technical verification, see **ALGORITHM.md**.

---

## Copyright Compliance

### Compliance Status: ✅ COMPLIANT

**No copyright infringement risk identified**

This tool has been thoroughly reviewed against:
- ✅ ESRI ArcGIS Pro implementations
- ✅ Enhanced_CostPath_withParameters toolset (2025)
- ✅ UK government and NATO mobility tools

All analysis confirms independent implementation. The use of standard algorithms (Dijkstra) and public domain data (NRMM, USCS) does not constitute infringement.

### For Complete Compliance Documentation

Refer to **COPYRIGHT_COMPLIANCE_SUMMARY.md** for:
- Executive summary of compliance verification
- Detailed analysis of each referenced tool
- Complete 20+ point compliance checklist (all verified ✅)
- Risk assessment matrix (all categories GREEN ✅)

---

## Installation Requirements

- **Python 3.7+**
- **ArcGIS Pro** (with Python environment)
- **Dependencies**:
  - NumPy (BSD License)
  - GDAL (MIT License)
  - Pandas (BSD License)
  - SciPy (BSD License)
  - arcpy (Esri proprietary)

---

## Usage

### Input Data Requirements

1. **Digital Elevation Model (DEM)**: Raster format (GeoTIFF recommended)
2. **Soil Classification Layer**: USCS classification codes
3. **Vegetation Classification**: NLCD or equivalent
4. **Hydrological Features**: Stream networks and water bodies
5. **Vehicle Specifications**: From NRMM data or custom definitions

### Output Products

- **Mobility Surface Raster**: Cost values for each terrain cell
- **Optimal Path Geometry**: Polyline feature of calculated route
- **Movement Statistics**: Distance, estimated time, terrain difficulty
- **Mobility Map**: Visualization of traversable vs. constrained areas
- **Detailed Report**: Analysis summary and parameters used

---

## Performance & Optimization

- **Algorithm Complexity**: O(n log n) where n = raster cell count
- **Processing Efficiency**: Optimized for large-scale DEMs (1M+ cells)
- **Memory Management**: Streaming raster processing for very large datasets
- **Parallelization**: Multi-core support for independent mobility factor calculations

---

## License

**GPL-2.0-or-later**

SPDX-License-Identifier: GPL-2.0-or-later
Copyright (c) 2026 Eui Soo SON

See LICENSE file for complete license text.

### External Libraries

All external dependencies retain their original licenses (BSD, MIT). See **ATTRIBUTION.md** for detailed license information.

---

## Documentation Index

| Document | Purpose | Audience |
|----------|---------|----------|
| **ATTRIBUTION.md** | Third-party data & library credits | Legal, Academic, All Users |
| **ALGORITHM.md** | Technical algorithm verification | Developers, Technical Reviewers |
| **DATA_SOURCES.md** | Complete reference for all standards used | Researchers, Compliance Officers |
| **COPYRIGHT_COMPLIANCE_SUMMARY.md** | Executive compliance verification | Legal, Management, Stakeholders |
| **README.md** (this file) | Project overview and quick start | All Users |

---

## Citation

If you use this tool in academic or professional publications, please cite as:

```bibtex
@software{son2026ccm,
  author = {Son, Eui Soo},
  title = {CCM Tool: Cross-Country Mobility Analysis Tool v0.60.7},
  year = {2026},
  url = {https://github.com/yourusername/ccm-tool}
}
```

And include the attribution statement from the **Data Sources & Attribution** section above.

---

## Support & Contributing

- **Issues**: Report bugs and request features via GitHub Issues
- **Documentation**: Comprehensive guides in `/docs` directory
- **Contributing**: Pull requests welcome; see CONTRIBUTING.md

---

## Acknowledgments

This tool builds upon decades of terrain mobility research, particularly:
- NATO Reference Mobility Model (NRMM) for vehicle performance specifications
- Dijkstra's shortest-path algorithm (1959)
- Raster-based GIS analysis principles (Tomlin, 1990)
- USCS soil classification standard (ASTM D5080)

---

**For detailed compliance verification and copyright status, see COPYRIGHT_COMPLIANCE_SUMMARY.md**

**Version**: 0.60.7  
**Last Updated**: 2026-09-18  
**License**: GPL-2.0-or-later  
**Copyright**: © 2026 Eui Soo SON
