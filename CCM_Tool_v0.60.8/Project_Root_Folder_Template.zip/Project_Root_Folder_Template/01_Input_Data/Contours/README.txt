[Contours] 폴더 (선택 사항)
====================
인식 키워드: contour, hypso, isoline

등고선(Contour Line) 데이터 — Vegetation 높이 정규화 정확도를
개선하는 데 쓰입니다. 없어도 무방합니다.
