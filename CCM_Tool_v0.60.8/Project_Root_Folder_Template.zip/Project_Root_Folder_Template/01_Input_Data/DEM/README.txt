[DEM] 폴더
====================
인식 키워드: dem, dtm, dsm, elevation, elev, srtm, cdem, hrdem, lidar, height

Digital Elevation Model 래스터를 넣으세요 (.tif, .img, .dem 등).
여러 개가 있으면 LiDAR/HRDEM > CDEM/SRTM/ASTER > 파일 크기 순으로
자동 랭킹되어 가장 정확도 높은 것이 선택됩니다.

DEM 대신 이미 계산된 Slope Regions(경사 폴리곤)을 쓰실 경우, 이
폴더는 비워두고 Step 1 화면에서 "Slope Regions" 파라미터에 직접
browse 해서 넣으세요 (자동 인식 키워드 없음 — 반드시 수동 입력).
