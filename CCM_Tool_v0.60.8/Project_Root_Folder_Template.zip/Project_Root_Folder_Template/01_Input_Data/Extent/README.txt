[Extent] 폴더
====================
인식 키워드: extent, aoi, boundary, study_area, studyarea, area_of_interest

분석 대상 지역(AOI) 폴리곤 — 반드시 Projected CRS여야 합니다
(Geographic CRS면 Step 1에서 CRS 경고가 뜹니다).

예) Extent\AOI_Lebanon.shp
