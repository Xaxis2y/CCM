[Hydro] 폴더 (선택 사항)
====================
인식 키워드: hydro, water, river, lake, stream

수계(호수/하천) 폴리곤 Feature Class를 넣으세요. 여러 레이어가
있으면 전부 감지되어 다중값(multi-value)으로 자동 로드됩니다
(중복은 자동 제거).

예) Hydro\HydroLAKES.shp, Hydro\HydroRIVERS.shp
