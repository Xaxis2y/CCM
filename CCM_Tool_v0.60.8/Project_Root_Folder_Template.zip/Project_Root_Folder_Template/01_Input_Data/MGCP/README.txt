[MGCP] 폴더
====================
인식 키워드: mgcp, facc, trd

여기에 MGCP/FACC 원본 데이터를 그대로 넣으세요:
  - .gpkg (GeoPackage)
  - .gdb (File Geodatabase)
  - Feature Class 캐시 폴더 / .shp cell 구조

폴더 이름이나 파일명에 "mgcp"가 들어있지 않아도, AP030 / BH080 /
DA010 같은 FACC 5자리 코드가 내용물에서 발견되면 자동으로 MGCP로
분류됩니다 (content sniffing).

DA010(토양/SMC), BH140(하천), AP030(도로) 등은 Step 0/Step 1에서
Soil / Hydrology / Contours 자동 채움에 쓰일 수 있습니다 — 단, 반드시
Step 1의 "MGCP Manifest" 파라미터에 Step 0가 만든
mgcp_manifest.json을 지정해야 자동 채움이 동작합니다.
