[Soil] 폴더
====================
인식 키워드: soil, slc, ssurgo, statsgo, hwsd, soilgrid

지원되는 소스 (정확도 우선순위: SSURGO > SLC/DSS > SoilGrids > HWSD
> 일반 Soil FC):
  - SSURGO (미국, ~1:24k)
  - SLC/DSS (캐나다)
  - SoilGrids (250m 래스터 폴더)
  - HWSD v2 (.mdb 또는 raster, 전지구 1km)
  - 일반 폴리곤 Feature Class (토양 타입 필드 포함)

예) Soil\HWSD2_DB_RASTER\HWSD2.mdb
예) Soil\SSURGO\soil_survey.gdb
