[Vegetation] 폴더 (선택 사항)
====================
인식 키워드: veg, vegetation, landcover, land_cover, lulc, canopy,
              forest, bio, lai, fcover, worldcover, nlcd, gedi

정확도 우선순위: Canada Bio(LAI/fCOVER/canopy) > GEDI >
WorldCover/NLCD > 일반 landcover

식생/토지피복 래스터 또는 Feature Class를 넣으세요.
