[Vehicle] 폴더
====================
인식 키워드: vehicle, fleet, platform

Vehicle Definitions CSV를 넣으세요. 필수 컬럼: name, vci_1, vci_50,
max_road_spd_kph (스캐너가 이 헤더들을 보고 CSV를 자동 인식합니다).

예) Vehicle\Vehicles_Can.csv

Tool 자체에 기본 번들 CSV도 포함되어 있어서(Vehicle_Data\Vehicles_Can.csv),
직접 CSV를 준비 안 해도 Step 1의 Required 필드는 채워집니다 — 단,
Step 2의 Vehicle 드롭다운은 이 CSV의 name 컬럼 값을 읽어서 채워지니,
드롭다운이 비어 보이면 이 CSV 경로/헤더를 다시 확인하세요.
