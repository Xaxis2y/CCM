이 폴더는 비워두세요.

Step 0b(Data Scanner)가 01_Input_Data를 스캔한 결과
(ccm_data_catalog.json, ccm_confidence_scores.json,
ccm_fitness_scores.json, CCM_Data_Intelligence_Report 등)를 이
폴더에 자동으로 씁니다. 사람이 직접 파일을 넣거나 지울 필요 없습니다.
