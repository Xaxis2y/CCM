====================================================================
CCM Tool — Project Root Folder Template
====================================================================

이 폴더는 CCM Tool(v0.60.x)의 "single-root architecture"에 맞춘
빈 템플릿입니다. 새 프로젝트(AOI)를 시작할 때마다 이 폴더 전체를
복사해서 새 이름으로 바꿔서 쓰세요.

--------------------------------------------------------------------
사용 방법 (새 프로젝트 시작할 때마다)
--------------------------------------------------------------------
1. 이 "Project_Root_Folder_Template" 폴더를 통째로 복사(Ctrl+C, Ctrl+V)
2. 복사본 이름을 프로젝트에 맞게 변경
   예) "Project_Root_Folder_Template - 복사본" → "AOI_Syria"
3. 원하는 위치로 이동 (예: C:\AOI_Syria)
4. 01_Input_Data\ 아래 각 하위 폴더에 실제 raw 데이터를 채워 넣기
   (각 하위 폴더 안에 있는 README 파일 참고)
5. ArcGIS Pro에서 CCM Tool 실행:
   - Step 1의 "Project Root Folder" 파라미터 = 이 폴더 자체
     (예: C:\AOI_Syria)
   - Step 1의 "Data Root Folder" 파라미터 = 비워두면 자동으로
     <Project Root>\01_Input_Data 를 사용함 (이미 이 구조와 일치)

--------------------------------------------------------------------
이 폴더 구조가 "왜" 이렇게 생겼는지
--------------------------------------------------------------------
CCM Tool은 하나의 Project Root Folder 아래에 다음 3가지를 스스로
만들고 관리합니다. 이 3개는 Tool 전용이니 절대 다른 프로젝트 파일과
섞지 마세요:

    01_Input_Data\   ← 당신이 raw 데이터를 채우는 곳 (아래 참고)
    02_Scan_Index\   ← Step 0b가 스캔 결과(ccm_data_catalog.json 등)를
                        자동으로 쓰는 곳. 절대 손대지 마세요. 비워두면 됨.
    03_Project.gdb   ← Step 0 또는 Step 1이 실행될 때 "자동으로" 생성.
                        ★★★ 이 폴더/파일을 미리 만들지 마세요! ★★★
                        arcpy.CreateFileGDB()로 만들어야 진짜 유효한
                        File Geodatabase가 됩니다. 사람이 그냥 빈
                        Windows 폴더를 "03_Project.gdb"라는 이름으로
                        직접 만들면 내부 시스템 테이블이 없어서
                        ArcGIS가 이를 손상된(invalid) GDB로 인식하고
                        Step 1/Step 2에서 에러가 납니다.

--------------------------------------------------------------------
01_Input_Data 하위 폴더 — 자동 인식 키워드
--------------------------------------------------------------------
CCM Tool의 Data Root 스캐너(ccm_data_discovery.py)는 폴더 이름에
아래 키워드가 "부분 문자열"로만 포함되어 있으면 자동으로 인식합니다.
즉, 폴더명을 꼭 아래처럼 쓸 필요는 없고, 키워드만 포함되면 됩니다
(예: "3. Soil Data - HWSD" 도 "soil"이 포함되어 있어서 인식됨).

    MGCP\        → mgcp, facc, trd
    Soil\        → soil, slc, ssurgo, statsgo, hwsd, soilgrid
    DEM\         → dem, dtm, dsm, elevation, elev, srtm, cdem, hrdem,
                    lidar, height
    Contours\    → contour, hypso, isoline   (선택 사항)
    Vegetation\  → veg, vegetation, landcover, lulc, canopy, forest,
                    bio, lai, fcover, worldcover, nlcd, gedi
    Hydro\       → hydro, water, river, lake, stream
    Vehicle\     → vehicle, fleet, platform
    Extent\      → extent, aoi, boundary, study_area, area_of_interest

  ⚠ 주의: "Slope Regions"는 자동 인식 키워드가 없습니다. DEM 대신
  이미 계산된 경사(slope) 폴리곤을 쓰실 경우, Step 1 화면에서
  "Slope Regions" 파라미터에 수동으로 직접 browse 해서 넣어야 합니다.

--------------------------------------------------------------------
체크리스트
--------------------------------------------------------------------
[ ] 01_Input_Data 하위 8개 폴더 중 실제 쓰는 것만 데이터로 채움
    (Extent, DEM 또는 Slope 중 하나는 필수. 나머지는 선택)
[ ] 02_Scan_Index 는 비워둠 (Tool이 자동 생성)
[ ] 03_Project.gdb 는 만들지 않음 (Tool이 자동 생성)
[ ] Step 1에서 Project Root Folder = 이 폴더(복사본) 경로로 지정
[ ] Step 1 실행 후 ccm_project.json이 이 폴더 루트에 생성됐는지 확인
[ ] Step 2 실행 전, ccm_project.json 안에 "project_gdb" 값이
    03_Project.gdb 실제 경로로 채워져 있는지 확인
====================================================================
